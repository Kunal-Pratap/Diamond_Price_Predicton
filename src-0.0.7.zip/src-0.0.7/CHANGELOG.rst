Changes
=======

0.0.7
-----
* Updated README to include links to pip and setuptools issues and
  explain what this package does.
* Updated installation script to exit with an error rather than
  normally.

0.0.6
-----
* Fix option parsing for some versions of distribute / setuptools.
* Change license to Apache 2.0.

0.0.5
-----
Fixed behaviour when run with ``easy_install``.

0.0.4
-----
Added manifest to package.

0.0.3
-----
Tagged 0.0.2 already without changing the version number.

0.0.2
-----
Updated README.

0.0.1
-----
Initial version.
